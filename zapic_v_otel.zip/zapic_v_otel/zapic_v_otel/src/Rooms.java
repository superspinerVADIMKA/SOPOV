public class Rooms {
    static int room;

    public static int getRoom() {
        return room;
    }

    public static void setRoom(int room) {
        Rooms.room = room;
    }
}
