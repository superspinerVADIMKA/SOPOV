import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    static ArrayList<Aministrator> Zapis = new ArrayList<>();
    public static void main(String[] args) {

            Aministrator amin = new Aministrator () ;

        Scanner scanner = new Scanner(System.in);
            amin.AddZapis("Name", "nameclient", 123, 2, Zapis);
            System.out.println(Zapis.size()) ;
            System.out.print("Введите кол-во записей: ");
            int count = scanner.nextInt();
            String[] names = new String[count];
            String[] surnames = new String[count];
            String[] phone = new String[count];
            int[] room = new int[count];
            System.out.println("Введите данные для каждой записи:");
            for (int i = 0; i < count; i++) {
                System.out.print("Введите имя " + (i+1) + ": ");
                names[i] = scanner.next();

                System.out.print("Введите фамилию " + (i+1) + ": ");
                surnames[i] = scanner.next();

                System.out.print("Введите номер телефона " + (i+1) + ": ");
                phone[i] = scanner.next();

                System.out.print("Введите номер комнаты " + (i+1) + ": ");
                room[i] = Integer.parseInt(scanner.next());
            }

            System.out.println("Новые записи в номера:");
            for (int i = 0; i < count; i++) {
                System.out.println("Запись " + (i+1) + ": " + names[i] + " " + surnames[i] + " " + phone[i] + " " + room[i]);
            }
        }

    }